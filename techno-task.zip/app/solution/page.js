import Solutions from '@/components/Pages/Solutions'
import React from 'react'

const page = () => {
  return (
    <div>
        <Solutions/>
    </div>
  )
}

export default page