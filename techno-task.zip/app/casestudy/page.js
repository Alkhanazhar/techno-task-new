import CaseStudy from '@/components/Pages/CaseStudy'
import React from 'react'

const page = () => {
  return (
    <div>
      <CaseStudy/>
    </div>
  )
}

export default page
