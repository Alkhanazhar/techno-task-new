import Pricing from '@/components/Pages/Pricing'
import React from 'react'

const page = () => {
  return (
    <div>
        <Pricing/>
    </div>
  )
}

export default page