import ContactUs from '@/components/Pages/ContactUs'
import React from 'react'

const page = () => {
  return (
    <div>
        <ContactUs/>
    </div>
  )
}

export default page