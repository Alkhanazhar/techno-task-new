(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_3691ab6e._.js",
  "static/chunks/components_Pages_CaseStudy_jsx_aed83c5d._.js"
],
    source: "dynamic"
});
