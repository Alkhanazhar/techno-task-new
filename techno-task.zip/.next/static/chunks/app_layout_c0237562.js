(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_b16c05c9._.css",
  "static/chunks/_386b5a75._.js"
],
    source: "dynamic"
});
