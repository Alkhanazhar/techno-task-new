(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_411f0a6f._.js",
  "static/chunks/node_modules_motion-dom_dist_es_2453d03e._.js",
  "static/chunks/node_modules_framer-motion_dist_es_bafe777e._.js",
  "static/chunks/node_modules_ogl_src_31d737fb._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854acb4._.js",
  "static/chunks/node_modules_gsap_8ed0561d._.js",
  "static/chunks/node_modules_a7cb4c47._.js"
],
    source: "dynamic"
});
