(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_b860aecf._.js",
  "static/chunks/_ce8d95f4._.js"
],
    source: "dynamic"
});
