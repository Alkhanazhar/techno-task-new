(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@tsparticles_engine_browser_985428d5._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854acb4._.js",
  "static/chunks/node_modules_motion-dom_dist_es_ed5d7820._.js",
  "static/chunks/node_modules_framer-motion_dist_es_24fdeb73._.js",
  "static/chunks/node_modules_868e46a3._.js",
  "static/chunks/_f3952fcd._.js"
],
    source: "dynamic"
});
